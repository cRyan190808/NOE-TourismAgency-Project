INSERT INTO HOTEL VALUES (0, 0, 'Zum güldenen Hirsch', 'Harry Hirsch', 'Susi', 'Hirschgasse 42/47/11', 'Hirschhausen', 'A-0815', '1234', 5, 50, 'www.zumgueldenenhirsch.at', false, false, true, true);
INSERT INTO HOTEL VALUES (1, 1, 'Drei Sterne und die Sonne', 'Sternwarte', 'Hänsel', 'Sterngasse 5', 'Alldorf', 'A-1234', '01234', 40, 4, 'www.dreisterne.at', false, true, false, true);
INSERT INTO HOTEL VALUES (2, 2, 'Zum wilden Eber', 'James Bond', 'Strolchi', 'Am Berg 7', 'Großebersdorf', 'A-007', '0987', 3, 3, 'www.zumwildeneber.at', true, true, true, true);
INSERT INTO HOTEL VALUES (3, 4, 'Beim Branntweiner', 'Ima Voll', 'Gretel', 'Weinberg 3', 'Alkohütten', 'A-1234', '546456', 1, 1, 'www.beimbranntweiner', true, false, true, false);
INSERT INTO HOTEL VALUES (4, 3, 'Das ABC', 'Il. Literat', 'der böse Wolf', 'Heinzelmännchenweg 3', 'Buchstaben', 'A-BCDEF', '9876', 2, 2, 'www.das-abc.at', false, true, false, false);
